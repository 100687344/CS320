package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import driver.AppointmentService;

class AppointmentServiceTest {

	private String id;
	private String description;
	private String longDescription;
	private Date date;
	private Date past;
	
	@BeforeEach
	void setUp() {
		id = "0123456789";
		description = "Test Description";
		date = new Date(2077, Calendar.DECEMBER, 2);
		longDescription = "Test Description Used For Testing That Will Cause An Error In The Application";
		past = new Date(0);
	}
	
	@Test
	void testNewAppointment() {	
		
		AppointmentService service = new AppointmentService();
		service.addAppointment();
		
		//No Null Values
		assertNotNull(service.getAppointmentList().get(0).getAppointmentId());
		assertNotNull(service.getAppointmentList().get(0).getAppointmentDate());
		assertNotNull(service.getAppointmentList().get(0).getAppointmentDescription());
		
		//Date Overload
		service.addAppointment(date);
		assertNotNull(service.getAppointmentList().get(1).getAppointmentId());
		assertEquals(date, service.getAppointmentList().get(1).getAppointmentId());
		assertNotNull(service.getAppointmentList().get(1).getAppointmentDescription());
		
		//Date And Description Overload
		service.addAppointment(date, description);
		assertNotNull(service.getAppointmentList().get(2).getAppointmentId());
		assertEquals(date, service.getAppointmentList().get(2).getAppointmentDate());
		assertEquals(description, service.getAppointmentList().get(2).getAppointmentDescription());
		
		//Each Appointment Is Unique By ID
		assertNotEquals(service.getAppointmentList().get(0).getAppointmentId(), service.getAppointmentList().get(1).getAppointmentId());
		assertNotEquals(service.getAppointmentList().get(0).getAppointmentId(), service.getAppointmentList().get(2).getAppointmentId());
		assertNotEquals(service.getAppointmentList().get(1).getAppointmentId(), service.getAppointmentList().get(2).getAppointmentId());
		
		//No Long Values
		assertThrows(IllegalArgumentException.class, ()-> service.addAppointment(past));
		assertThrows(IllegalArgumentException.class, ()-> service.addAppointment(date, longDescription));
	}
	
	@Test
	void testDeleteAppointment() throws Exception {
		
		AppointmentService service = new AppointmentService();
		
		//Add Appointments To List
		service.addAppointment();
		service.addAppointment();
		service.addAppointment();
		
		//Assign IDs
		String firstId = service.getAppointmentList().get(0).getAppointmentId();
		String secondId = service.getAppointmentList().get(1).getAppointmentId();
		String thirdId = service.getAppointmentList().get(2).getAppointmentId();
		
		//Unique Appointments By ID
		assertNotEquals(firstId, secondId);
		assertNotEquals(firstId, thirdId);
		assertNotEquals(secondId, thirdId);
		assertNotEquals(id, firstId);
		assertNotEquals(id, secondId);
		assertNotEquals(id, thirdId);
		
		assertThrows(Exception.class, ()-> service.deleteAppointment(id));
		
		//Delete Function
		service.deleteAppointment(firstId);
		assertThrows(Exception.class, ()-> service.deleteAppointment(firstId));
		assertNotEquals(firstId, service.getAppointmentList().get(0).getAppointmentId());
	}

}

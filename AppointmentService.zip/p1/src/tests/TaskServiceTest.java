package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

import driver.TaskService;

class TaskServiceTest {

	private String id;
	private String name;
	private String description;
	private String tooLongName;
	private String tooLongDescription;

	@BeforeEach
	void setUp() {
		id = "0123456789";
		name = "Task Service Test";
		description = "Default Test Description";
		tooLongName = "Test Name Is Too Long And Will Cause An Error";
		tooLongDescription = "The Quick Red Fox Jumped Over The Lazy Brown Dog And By Doing So Has Caused An Error For The Description";
	}

	@Test
	void newTaskTest() {
		TaskService service = new TaskService();
		service.newTask();
		Assertions.assertNotNull(service.getTasks().get(0).getTaskId());
		Assertions.assertNotEquals("INITIAL", service.getTasks().get(0).getTaskId());
	}

	@Test
	void newTaskNameTest() {
		TaskService service = new TaskService();
		service.newTask(name);
		Assertions.assertNotNull(service.getTasks().get(0).getName());
		Assertions.assertEquals(name, service.getTasks().get(0).getName());
	}

	@Test
	void newTaskDescriptionTest() {
		TaskService service = new TaskService();
		service.newTask(name, description);
		Assertions.assertNotNull(service.getTasks().get(0).getDescription());
		Assertions.assertEquals(description, service.getTasks().get(0).getDescription());
	}

	@Test
	void newTaskTooLongNameTest() {
		TaskService service = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> service.newTask(tooLongName));
	}

	@Test
	void newTaskTooLongDescriptionTest() {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class, () -> service.newTask(name, tooLongDescription));
	}

	@Test
	void newTaskNameNullTest() {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class, () -> service.newTask(null));
	}

	@Test
	void newTaskDescriptionNullTest() {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class, () -> service.newTask(name, null));
	}

	@Test
	void deleteTaskTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		assertEquals(1, service.getTasks().size());
		service.deleteTask(service.getTasks().get(0).getTaskId());
		assertEquals(0, service.getTasks().size());
	}

	@Test
	void deleteTaskNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		assertEquals(1, service.getTasks().size());
		assertThrows(Exception.class, () -> service.deleteTask(id));
		assertEquals(1, service.getTasks().size());
	}

	@Test
	void updateNameTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		service.updateName(service.getTasks().get(0).getTaskId(), name);
		assertEquals(name, service.getTasks().get(0).getName());
	}

	@Test
	void updateDescriptionTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		service.updateDescription(service.getTasks().get(0).getTaskId(), description);
		assertEquals(description, service.getTasks().get(0).getDescription());
	}

	@Test
	void updateNameNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		assertThrows(Exception.class, () -> service.updateName(id, name));
	}

	@Test
	void updateDescriptionNotFoundTest() throws Exception {
		TaskService service = new TaskService();
		service.newTask();
		assertThrows(Exception.class, () -> service.updateDescription(id, description));
	}

	@RepeatedTest(4)
	void UuidTest() {
		TaskService service = new TaskService();
		service.newTask();
		service.newTask();
		service.newTask();
		assertEquals(3, service.getTasks().size());
		assertNotEquals(service.getTasks().get(0).getTaskId(), service.getTasks().get(1).getTaskId());
		assertNotEquals(service.getTasks().get(0).getTaskId(), service.getTasks().get(2).getTaskId());
		assertNotEquals(service.getTasks().get(1).getTaskId(), service.getTasks().get(2).getTaskId());
	}

}

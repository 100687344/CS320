package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import driver.Appointment;

class AppointmentTest {

	private String id;
	private String description;
	private String longId;
	private String longDescription;
	private Date date;
	private Date past;
	
	@BeforeEach
	void setUp() {
		id = "0123456789";
		description = "Test Description";
		date = new Date(2077, Calendar.DECEMBER, 2);
		longId = "00112233445566778899";
		longDescription = "Test Description Used For Testing That Will Cause An Error In The Application";
		past = new Date(0);
	}
	
	@Test
	void testUpdateAppointmentId() {
		Appointment testAppointment = new Appointment();
		assertThrows(IllegalArgumentException.class, ()-> testAppointment.updateAppointmentId(null));
		assertThrows(IllegalArgumentException.class, ()-> testAppointment.updateAppointmentId(longId));
		testAppointment.updateAppointmentId(id);
		assertEquals(id, testAppointment.getAppointmentId());
	}
	
	@Test
	void testGetAppointmentId() {
		Appointment testAppointment = new Appointment(id);
		assertNotNull(testAppointment.getAppointmentId());
		assertEquals(testAppointment.getAppointmentId().length(), 10);
		assertEquals(id, testAppointment.getAppointmentId());
	}
	
	@Test
	void testUpdateDate() {
		Appointment testAppointment = new Appointment();
		assertThrows(IllegalArgumentException.class, ()-> testAppointment.updateAppointmentDate(null));
		assertThrows(IllegalArgumentException.class, ()-> testAppointment.updateAppointmentDate(past));
		testAppointment.updateAppointmentDate(date);
		assertEquals(date, testAppointment.getAppointmentDate());
	}
	
	@Test
	void testGetAppointmentDate() {
		Appointment testAppointment = new Appointment(id, date);
		assertNotNull(testAppointment.getAppointmentDate());
		assertEquals(date, testAppointment.getAppointmentDate());
	}
	
	@Test
	void testUpdateDescription() {
		Appointment testAppointment = new Appointment();
		assertThrows(IllegalArgumentException.class, ()-> testAppointment.updateAppointmentDescription(null));
		assertThrows(IllegalArgumentException.class, ()-> testAppointment.updateAppointmentDescription(longDescription));
		testAppointment.updateAppointmentDescription(description);
		assertEquals(description, testAppointment.getAppointmentDescription());
	}
	
	@Test
	void testGetDescription() {
		Appointment testAppointment = new Appointment();
		assertNotNull(testAppointment.getAppointmentDescription());
		assertTrue(testAppointment.getAppointmentDescription().length() <= 50);
		assertEquals(description, testAppointment.getAppointmentDescription());
	}

}

package driver;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class AppointmentService {
	
	//Declarations
	private List<Appointment> appointments = new ArrayList<>();
	
	//Create Unique ID
	private String createId() {
		
		//https://www.geeksforgeeks.org/java-util-uuid-class-java/
		//Used source to help with creation of unique ID.
		return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
	//Add Appointment With Only ID
	public void addAppointment() {
			
		Appointment appt = new Appointment(createId());
		appointments.add(appt);
	}

	//Add Appointment With ID And Date
	public void addAppointment(Date date) {
			
		Appointment appt = new Appointment(createId(), date);
			appointments.add(appt);
	}
	
	//Add Appointment With ID, Date, And Description
	public void addAppointment(Date date, String description) {
			
		Appointment appt = new Appointment(createId(), date, description);
		appointments.add(appt);
	}	
		
	//Delete Task
	public void deleteAppointment(String id) throws Exception {
		
		appointments.remove(searchAppointments(id));
	}
	
	//Appointment List Copy
	public List<Appointment> getAppointmentList(){
		return appointments;
	}
	
	//Finds Appointment Given Appointment ID
	private Appointment searchAppointments(String id) throws Exception {
		
		int index = 0;
		while (index < appointments.size()){
			if(id.equals(appointments.get(index).getAppointmentId())){
				return appointments.get(index);
			}
			index++;
		}
		throw new Exception("No Appointment Found");
	}


}

package driver;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ContactService {
	
	//Declarations
	private String uniqueId;
	
	{
		uniqueId = UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
	private List<Contact> contactList = new ArrayList<>();
	
	//Default Construct
	public ContactService() {
		contactList.add(new Contact(uniqueId));
	}
	
	//First Name Overload
	public ContactService(String firstName) {
		contactList.add(new Contact(uniqueId, firstName));
	}
	
	//Full Name Overload
	public ContactService(String firstName, String lastName) {
		contactList.add(new Contact(uniqueId, firstName, lastName));
	}
	
	//Full Name And Phone Overload
	public ContactService(String firstName, String lastName, String phoneNumber) {
		contactList.add(new Contact(uniqueId, firstName, lastName, phoneNumber));
	}
	
	//Full Name, Phone, Address Overload
	public ContactService(String firstName, String lastName, String phoneNumber, String address) {
		contactList.add(new Contact(uniqueId, firstName, lastName, phoneNumber, address));
	}
	
	//New Contact
	public Contact newContact() {
		Contact contact = new Contact(newUniqueId());
		contactList.add(contact);
		return contact;
	}
	
	//Delete Contact
	public void deleteContact(Contact contact) {
		contactList.remove(contact);
	}
	
	//Update First Name
	public void updateFirstName(Contact contact, String firstName) {
		contact.updateFirstName(firstName);
	}
	
	//Update Last Name
	public void updateLastName(Contact contact, String lastName) {
		contact.updateLastName(lastName);
	}
	
	//Update Phone Number
	public void updatePhoneNumber(Contact contact, String phoneNumber) {
		contact.updatePhoneNumber(phoneNumber);
	}
	
	//Update Address
	public void updateAddress(Contact contact, String address) {
		contact.updateContactAddress(address);
	}
	
	//Get Contact List
	public List<Contact> getContactList(){
		return contactList;
	}
	
	//Create New ID
	private String newUniqueId() {
		return uniqueId = UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
}

package driver;

import java.util.Date;

public class Appointment {
	
	//Final Value Declarations
	final private byte APPOINTMENT_ID_LENGTH;
	final private byte APPOINTMENT_DESCRIPTION_LENGTH;
	final private String INITIAL_VALUE;
	
	//Declarations
	private String appointmentId;
	private Date appointmentDate;
	private String appointmentDescription;
	
	//Set Final Values
	{
		APPOINTMENT_ID_LENGTH = 10;
		APPOINTMENT_DESCRIPTION_LENGTH = 50;
		INITIAL_VALUE = "INITIAL";
	}
	
	//Default Construct
	public Appointment() {
		
		Date currentDate = new Date();
		appointmentId = INITIAL_VALUE;
		appointmentDate = currentDate;
		appointmentDescription = INITIAL_VALUE;
	}
	
	//ID Overload Construct
	public Appointment(String id) {
		
		Date today = new Date();
	    updateAppointmentId(id);
	    appointmentDate = today;
	    appointmentDescription = INITIAL_VALUE;
	}
	
	//ID And Date Overload Construct
	public Appointment(String id, Date date) {
		
		updateAppointmentId(id);
	    updateAppointmentDate(date);
		appointmentDescription = INITIAL_VALUE;
	}
	
	//ID, Date, Description Overload Construct
	public Appointment(String id, Date date, String description) {
		
		updateAppointmentId(id);
	    updateAppointmentDate(date);
		updateAppointmentDescription(description);
	}
	
	//Update Appointment ID
	public void updateAppointmentId(String id) {
		
		if(id == null) 
			throw new IllegalArgumentException("Invalid Appointment ID");
		else if(id.length() > APPOINTMENT_ID_LENGTH)
			throw new IllegalArgumentException("Appointment ID Exceeds " + APPOINTMENT_ID_LENGTH + " Characters");
		else
			this.appointmentId = id;
	}
	
	//Get Appointment ID
	public String getAppointmentId(){
		return appointmentId;
	}
	
	//Update Appointment Date
	public void updateAppointmentDate(Date date) {
		
		if(date == null) 
			throw new IllegalArgumentException("Invalid Appointment Date");
		else if(date.before(new Date()))
			throw new IllegalArgumentException("Date Is In The Past");
		else
			this.appointmentDate = date;
	}
	
	//Get Appointment Date
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	//Update Appointment ID
	public void updateAppointmentDescription(String description) {
		
		if(description == null) 
			throw new IllegalArgumentException("Invalid Appointment Description");
		else if(description.length() > APPOINTMENT_DESCRIPTION_LENGTH)
			throw new IllegalArgumentException("Appointment Description Exceeds " + APPOINTMENT_DESCRIPTION_LENGTH + " Characters");
		else
			this.appointmentDescription = description;
	}
	
	//Get Appointment Description
	public String getAppointmentDescription() {
		return appointmentDescription;
	}
}

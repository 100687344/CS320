package driver;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TaskService {
	
	//Declarations
	private final List<Task> tasks = new ArrayList<>();
	
	//Create Unique ID
	private String newUniqueId() {
		return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
	//Search Tasks
	private Task searchTasks(String id) throws Exception{
		int index = 0;
		while(index < tasks.size()) {
			if(id.equals(tasks.get(index).getTaskId()))
				return tasks.get(index);
			index++;
		}
		throw new Exception("Task Not Found");
	}
	
	//New Default Task
	public void newTask() {
		Task task = new Task(newUniqueId());
		tasks.add(task);
	}
	
	//New Task With Name
	public void newTask(String name) {
		Task task = new Task(newUniqueId(), name);
		tasks.add(task);
	}
	
	//New Task With Name And Description
	public void newTask(String name, String description) {
		Task task = new Task(newUniqueId(), name, description);
		tasks.add(task);
	}
	
	//Delete Task
	public void deleteTask(String id) throws Exception{
		tasks.remove(searchTasks(id));
	}
	
	//Update Name
	public void updateName(String id, String name) throws Exception{
		searchTasks(id).setName(name);
	}
	
	//Update Description
	public void updateDescription(String id, String description) throws Exception{
		searchTasks(id).setDescription(description);
	}
	
	//Get Task List
	public List<Task> getTasks(){
		return tasks;
	}

}

package driver;

public class Task {
	
	//Declarations
	private String taskId;
	private String name;
	private String description;
	
	//Default Construct
	public Task() {
		taskId = "INITAL";
		name = "INITIAL";
		description = "INITIAL DESCRIPTION";
	}
	
	//ID Overload
	public Task(String taskId) {
		checkTaskId(taskId);
		name = "INITIAL";
		description = "INITIAL DESCRIPTION";
	}
	
	//ID And Name Overload
	public Task(String taskId, String name) {
		checkTaskId(taskId);
	    setName(name);
	    description = "INITIAL DESCRIPTION";
	}
	
	//ID, Name, Description Overload
	public Task(String taskId, String name, String description) {
		checkTaskId(taskId);
	    setName(name);
	    setDescription(description);
	}
	
	//Get ID
	public final String getTaskId() {
		return taskId;
	}
	
	//Get Name
	public final String getName() {
		return name;
	}
	
	//Get Description
	public final String getDescription() {
		return description;
	}
	
	//Set Name
	public void setName(String name) {
		if (name == null || name.length() > 20) 
		      throw new IllegalArgumentException("Task Name Invalid. Name Cannot Exceed 20 Characters And Cannot Be Empty.");
		     else 
		      this.name = name;
	}
	
	//Set Description
	public void setDescription(String description) {
		if (description == null || description.length() > 50) 
		      throw new IllegalArgumentException("Task Description Invalid. Description Cannot Exceed 50 Characters And Cannot Be Empty.");
		else 
		      this.description = description;	    
	}
	
	//Check ID
	private void checkTaskId(String taskId) {
		if (taskId == null || taskId.length() > 10)
		      throw new IllegalArgumentException("Task ID Longer Than 10 Characters");
		     else 
		      this.taskId = taskId;
	}
	
	

}
